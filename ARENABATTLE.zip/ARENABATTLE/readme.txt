Care sunt regulile jocului?

	In jocul Arena Battle, utilizatorul isi alege una din cele 3 optiuni de luptator: Mage, Warrior, Healer, fiecare cu avantajele si dezavantajele lui, de exemplu 
Warrior-ul da cel mai mare damage dar are o sansa de ratare per atac de 40%, Healer-ul se poate vindeca de maxim 2 ori, orice luptator poate sa se apare de orice atac
apasand tasta 'g'.Lupta se desfasoara pe o arena 6x6, impotriva unui luptator controlat de AI, presarata cu diferite obstacole precum ziduri sau cactusi(daca se intra pe un cactus
luptatorul primeste 10 damage).Cele 2 parti sunt asezate random in arena pe pozitii diferite, iar prima mutare se alege tot la intamplare, jocul se termina atunci cand un luptatorr are mai putin de 0 hp.Scopul jocului este ca utilizatorul sa invinga AI-ul cat mai strategic si eficient.Pe harta utilizatorul va fi reprezentat de o litera mica, iar adversarul cu o litera mare.

Care sunt clasele?

	-Clasa AI;
	-Clasa Arena;
	-CLasa Luptator care este clasa de baza pentru clasele: Mage, Warrior, Healer, Jucator;
	-Clasa Exceptii.

Care sunt functiile virtuale utilizate?
	
	-functia ataca() are o implementare pentru fiecare clasa derivata cu un damage diferit si un mesaj corespunzator
	-si functiile getSimbol, getSansaRatare

Exceptii folosite:
	-ArenaPlinaException
	-PozitieOcupataException
	-MutareInvalidaException
	-AtacInexistentException


Bibliografie:
-Cursurile POO de pe Microsoft Teams;
-Youtube;
-Stack Overflow;
-https://github.com/mcmarius/poo/tree/master/tema-2.

Link GitHub:
https://github.com/DennisRadoi


