#include "AI.h"
#include "Jucator.h"
#include <cmath>
#include <iostream>
#include <memory>


AI::AI(std::shared_ptr<Luptator> f)
    : luptator(std::move(f))
{}

void AI::executaRunda(Arena& arena)
{
    if (!luptator || !luptator->esteViu())
        return;

    auto healer = std::dynamic_pointer_cast<Healer>(luptator);
    if (healer)
    {
        if (healer->getHP() <= healer->getViata()/2 && healer->maiPoateVindeca())
        {
            healer->vindecare();
            return;
        }
    }

    for (const auto& tinta : arena.getListaLuptatori())
    {
        auto juc = std::dynamic_pointer_cast<Jucator>(tinta);
        if (juc && juc->esteViu())
        {
            int dx = tinta->getX() - luptator->getX();
            int dy = tinta->getY() - luptator->getY();

            if (std::abs(dx) + std::abs(dy) == 1)
            {
                luptator->ataca(*tinta);
                return;
            }
            else
            {
                int pasX = 0, pasY = 0;
                if (std::abs(dx) > std::abs(dy))
                    pasX = (dx > 0) ? 1 : -1;
                else if (dy != 0)
                    pasY = (dy > 0) ? 1 : -1;

                int nouX = luptator->getX() + pasX;
                int nouY = luptator->getY() + pasY;

                if (nouX >= 0 && nouX < arena.getLatime() &&
                    nouY >= 0 && nouY < arena.getInaltime())
                {
                    if (!arena.esteZid(nouX, nouY))
                    {
                        try {
                            arena.mutaLuptator(luptator, pasX, pasY);
                        } catch (...)
                        {}
                    }
                }
                return;
            }
        }
    }
}

std::shared_ptr<Luptator> AI::getLuptator() const
{
    return luptator;
}

