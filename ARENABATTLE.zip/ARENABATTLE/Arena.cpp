#pragma once
#include "Arena.h"
#include <cstdlib>
#include <ctime>
#include <cmath>

void Arena::adaugaLuptator(std::shared_ptr<Luptator> f)
{
    if (luptatori.size() >= latime * inaltime)
        throw ArenaPlinaException("Arena este plina! Nu mai poti adauga jucatori.");

    int x, y;
    bool gasit = false;

    do
    {
        x = rand() % latime;
        y = rand() % inaltime;
        gasit = true;

        for (const auto& alt : luptatori)
        {
            if (alt->esteViu() && alt->getX() == x && alt->getY() == y)
            {
                gasit = false;
                break;
            }
        }
    }
    while (!gasit);

    f->setPoz(x, y);
    luptatori.push_back(f);
}

void Arena::afiseazaArena() const
{
    for (int y = 0; y < inaltime; ++y)
    {
        for (int x = 0; x < latime; ++x)
        {
            bool gasit = false;

            for (const auto& f : luptatori)
            {
                if (!f->esteViu())
                    continue;

                if (f->getX() == x && f->getY() == y)
                {
                    std::cout << f->getSimbol() << " ";
                    gasit = true;
                    break;
                }
            }

            if (!gasit)
            {
                if (ziduri[x][y])
                    std::cout << "# ";
                else if (cactusi[x][y])
                    std::cout << "* ";
                else
                    std::cout << ". ";
            }
        }

        std::cout << "\n";
    }

    std::cout << "\n";
}

void Arena::mutaLuptator(std::shared_ptr<Luptator> f, int dx, int dy)
{
    int nouX = f->getX() + dx;
    int nouY = f->getY() + dy;

    if (nouX < 0 || nouX >= latime || nouY < 0 || nouY >= inaltime)
        throw MutareInvalidaException("Mutare invalida, ai iesit din arena!");

    if (ziduri[nouX][nouY])
        throw MutareInvalidaException("Mutare invalida, nu te poti muta pe un zid!");

    if (cactusi[nouX][nouY])
    {
        std::cout << f->getNume() << " a calcat pe un cactus! Pierde 10 HP!\n";
        f->incaseazaDamage(10);
    }

    for (const auto& alt : luptatori)
    {
        if (alt != f && alt->esteViu() &&
            alt->getX() == nouX && alt->getY() == nouY)
        {
            throw PozitieOcupataException("Pozitia este ocupata deja de alt luptator!");
        }
    }

    f->setPoz(nouX, nouY);
}

std::shared_ptr<Luptator> Arena::getLuptatorLaPozitie(int x, int y) const
{
    for (const auto& f : luptatori)
    {
        if (!f->esteViu())
            continue;

        if (f->getX() == x && f->getY() == y)
            return f;
    }

    return nullptr;
}

const std::vector<std::shared_ptr<Luptator>>& Arena::getListaLuptatori() const
{
    return luptatori;
}

void Arena::initObstacole()
{
    const int nrZiduri = 1 + rand() % 3;
    const int nrCactusi = 1 + rand() % 3;

    int ziduriPuse = 0;
    while (ziduriPuse < nrZiduri)
    {
        int x = rand() % latime;
        int y = rand() % inaltime;

        if (!ziduri[x][y] && !cactusi[x][y])
        {
            ziduri[x][y] = true;
            ziduriPuse++;
        }
    }

    int cactusiPusi = 0;
    while (cactusiPusi < nrCactusi)
    {
        int x = rand() % latime;
        int y = rand() % inaltime;

        if (!ziduri[x][y] && !cactusi[x][y])
        {
            cactusi[x][y] = true;
            cactusiPusi++;
        }
    }
}

int Arena::getLatime() const
{
    return latime;
}

int Arena::getInaltime() const
{
    return inaltime;
}

bool Arena::esteZid(int x, int y) const
{
    return ziduri[x][y];
}
bool Arena::jocTerminat() const
{
    int vii = 0;

    for (const auto& f : luptatori)
    {
        if (f->esteViu())
            ++vii;
    }

    return vii <= 1;
}
