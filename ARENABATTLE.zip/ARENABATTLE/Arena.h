#pragma once

#include <vector>
#include <memory>
#include <iostream>
#include <stdexcept>
#include "Luptator.h"
#include "Exceptii.h"

class Arena
{
private:
    static const int latime = 6;
    static const int inaltime = 6;
    std::vector<std::shared_ptr<Luptator>> luptatori;
    bool ziduri[latime][inaltime]{};
    bool cactusi[latime][inaltime]{}; // initializate cu false din start

public:
    void adaugaLuptator(std::shared_ptr<Luptator> f);
    void afiseazaArena() const;
    void mutaLuptator(std::shared_ptr<Luptator> f, int dx, int dy);
    std::shared_ptr<Luptator> getLuptatorLaPozitie(int x, int y) const;
    const std::vector<std::shared_ptr<Luptator>>& getListaLuptatori() const;

    bool jocTerminat() const;

    void initObstacole();
    bool esteZid(int x, int y) const;
    int getLatime() const;
    int getInaltime() const;
};
