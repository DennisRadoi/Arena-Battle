#include "Luptator.h"
#include <iostream>
#include <cstdlib>

int Luptator::sansaCritic = 20;

Luptator::Luptator(const std::string& n, int startX, int startY, int viata)
    : nume(n), x(startX), y(startY), hp(viata), hpMAX(viata) {}

Luptator::Luptator(const Luptator& other)
    : nume(other.nume), hp(other.hp), hpMAX(other.hpMAX), x(other.x), y(other.y), aparare(other.aparare) {}

Luptator& Luptator::operator=(const Luptator& other)
{
    if (this != &other)
    {
        nume = other.nume;
        hp = other.hp;
        hpMAX = other.hpMAX;
        x = other.x;
        y = other.y;
        aparare = other.aparare;
    }
    return *this;
}

bool Luptator::esteAI() const
{
    return false;
}

bool Luptator::esteViu() const
{
    return hp > 0;
}

void Luptator::setPoz(int nouX, int nouY)
{
    x = nouX;
    y = nouY;
}

int Luptator::getX() const
{
    return x;
}

int Luptator::getY() const
{
    return y;
}

std::string Luptator::getNume() const
{
    return nume;
}

int Luptator::getHP() const
{
    return hp;
}

int Luptator::getViata() const
{
    return hpMAX;
}

void Luptator::incaseazaDamage(int dmg)
{
    if (seApara())
        dmg = dmg * 60 / 100;
    hp -= dmg;
    if (hp < 0) hp = 0;
}

void Luptator::vindeca(int v)
{
    hp += v;
    if (hp > hpMAX) hp = hpMAX;
}

void Luptator::startAparare()
{
    aparare = true;
}

void Luptator::stopAparare()
{
    aparare = false;
}

bool Luptator::seApara() const
{
    return aparare;
}

bool Luptator::rateazaAtacul() const
{
    return (rand() % 100) < getSansaRatare();
}

void Luptator::seteazaSansaCritic(int sansa)
{
    sansaCritic = sansa;
}

int Luptator::getSansaCritic()
{
    return sansaCritic;
}

bool Luptator::areCritic() const
{
    return (rand() % 100) < sansaCritic;
}

// ----Mage----

Mage::Mage(const std::string& n, int x, int y)
    : Luptator(n, x, y, 100) {}

Mage::Mage(const Mage& other) : Luptator(other) {}

Mage& Mage::operator=(const Mage& other)
{
    Luptator::operator=(other);
    return *this;
}

void Mage::ataca(Luptator& target)
{
    if (rateazaAtacul())
    {
        std::cout << getNume() << " a ratat atacul!\n";
        return;
    }

    int dmg = 20;
    if (areCritic())
    {
        dmg *= 2;
        std::cout << "Lovitura critica!\n";
    }

    target.incaseazaDamage(dmg);
    std::cout << getNume() << " lanseaza o tornada de foc catre " << target.getNume() << std::endl;
}

std::string Mage::getSimbol() const
{
    return "M";
}

int Mage::getSansaRatare() const
{
    return 15;
}

// ----Warrior-----

Warrior::Warrior(const std::string& n, int x, int y)
    : Luptator(n, x, y, 120) {}

Warrior::Warrior(const Warrior& other) : Luptator(other) {}

Warrior& Warrior::operator=(const Warrior& other)
{
    Luptator::operator=(other);
    return *this;
}

void Warrior::ataca(Luptator& tinta)
{
    if (rateazaAtacul())
    {
        std::cout << getNume() << " a ratat atacul!\n";
        return;
    }

    int dmg = 30;
    if (areCritic())
    {
        dmg *= 2;
        std::cout << "Lovitura critica!\n";
    }

    tinta.incaseazaDamage(dmg);
    std::cout << getNume() << " loveste cu sabia pe " << tinta.getNume() << std::endl;
}

std::string Warrior::getSimbol() const
{
    return "W";
}

int Warrior::getSansaRatare() const
{
    return 40;
}

// ----Healer-----

Healer::Healer(const std::string& n, int x, int y)
    : Luptator(n, x, y, 90) {}

Healer::Healer(const Healer& other)
    : Luptator(other), numarVindecari(other.numarVindecari) {}

Healer& Healer::operator=(const Healer& other)
{
    if (this != &other)
    {
        Luptator::operator=(other);
        numarVindecari = other.numarVindecari;
    }
    return *this;
}

void Healer::ataca(Luptator& tinta)
{
    if (rateazaAtacul())
    {
        std::cout << getNume() << " a ratat atacul!\n";
        return;
    }

    int dmg = 15;
    if (areCritic())
    {
        dmg *= 2;
        std::cout << "Lovitura critica!\n";
    }

    tinta.incaseazaDamage(dmg);
    std::cout << getNume() << " arunca un fulger sacru spre " << tinta.getNume() << "!\n";
}

void Healer::vindecare()
{
    if (numarVindecari > 0)
    {
        vindeca(20);
        numarVindecari--;
        std::cout << getNume() << " se vindecă (+20 HP)! Vindecari ramase: "
                  << numarVindecari << " | HP curent: " << getHP() << "\n";
    }
    else
        std::cout << getNume() << " nu mai are vindecari disponibile!\n";
}

std::string Healer::getSimbol() const
{
    return "H";
}

bool Healer::maiPoateVindeca() const
{
    return numarVindecari > 0;
}

void Healer::consumaVindecare()
{
    if (numarVindecari > 0) numarVindecari--;
}

int Healer::getNumarVindecari() const
{
    return numarVindecari;
}

int Healer::getSansaRatare() const
{
    return 15;
}
