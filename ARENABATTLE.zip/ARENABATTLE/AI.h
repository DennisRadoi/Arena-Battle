#pragma once

#include <memory>
#include "Luptator.h"
#include "Arena.h"

class AI
{
private:
    std::shared_ptr<Luptator> luptator;

public:
    AI(std::shared_ptr<Luptator> f);

    void executaRunda(Arena& arena);
    std::shared_ptr<Luptator> getLuptator() const;
};
