#include "Jucator.h"
#include "Exceptii.h"
#include <iostream>
#include <cmath>

Jucator::Jucator(std::string& nume, int x, int y, std::shared_ptr<Luptator> stilLupta)
    : Luptator(nume, x, y, stilLupta->getHP()), stil(std::move(stilLupta))
{
    simbol = stil->getSimbol();
}

void Jucator::ataca(Luptator& tinta)
{
    stil->ataca(tinta);
}

std::string Jucator::getSimbol() const
{
    if (simbol == "M") return "m";
    if (simbol == "W") return "w";
    if (simbol == "H") return "h";
    return simbol;
}

void Jucator::decideActiune(Arena& arena, std::shared_ptr<Jucator> self)
{
    std::cout << "Alege urmatoarea miscare:\n";
    std::cout << "w - sus\n"
              << "d - dreapta\n"
              << "s - jos\n"
              << "a - stanga\n"
              << "j - ataca\n"
              << "h - vindeca (doar Healer)\n"
              << "g - apara\n";

    char comanda;
    std::cin >> comanda;

    int dx = 0, dy = 0;

    switch (comanda)
    {
        case 'w': dy = -1; break;
        case 's': dy = 1; break;
        case 'a': dx = -1; break;
        case 'd': dx = 1; break;

        case 'j':
        {
            bool atacat = false;
            for (int i = -1; i <= 1; ++i)
            {
                for (int j = -1; j <= 1; ++j)
                {
                    if (abs(i) + abs(j) != 1) continue;
                    int tx = getX() + i;
                    int ty = getY() + j;
                    auto tinta = arena.getLuptatorLaPozitie(tx, ty);
                    if (tinta && tinta->esteViu() && tinta.get() != this)
                    {
                        ataca(*tinta);
                        atacat = true;
                        break;
                    }
                }
                if (atacat) break;
            }

            if (!atacat)
                throw AtacInexistentException("Nu exista inamic de atacat in apropiere!");
            return;
        }

        case 'h':
        {
            auto healerStil = std::dynamic_pointer_cast<Healer>(stil);
            if (healerStil && healerStil->maiPoateVindeca())
            {
                this->vindeca(20);
                healerStil->consumaVindecare();
                std::cout << getNume() << " se vindeca (+20 HP)! Vindecari ramase: "
                          << healerStil->getNumarVindecari() << " | HP curent: " << getHP() << "\n";
            }
            else if (healerStil)
                std::cout << "Nu mai ai vindecari disponibile!\n";
            else
                std::cout << "Nu esti un Healer!\n";
            return;
        }

        case 'g':
        {
            startAparare();
            std::cout << getNume() << " intra in modul de aparare!\n";
            return;
        }

        default:
            std::cout << "Comanda necunoscuta.\n";
            return;
    }

    try
    {
        arena.mutaLuptator(self, dx, dy);
        std::cout << "Te-ai mutat la (" << getX() << ", " << getY() << ")\n";
    }
    catch (const std::exception& e)
    {
        std::cout << "Mutare invalida: " << e.what() << "\n";
    }
}

int Jucator::getSansaRatare() const
{
    return stil ? stil->getSansaRatare() : 0;
}

