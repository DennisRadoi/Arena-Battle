#pragma once

#include <exception>
#include <string>

class ExceptieArena : public std::runtime_error
{
    using std::runtime_error::runtime_error;
};

class ArenaPlinaException : public ExceptieArena
{
    using ExceptieArena::ExceptieArena;
};

class PozitieOcupataException : public ExceptieArena
{
    using ExceptieArena::ExceptieArena;
};

class MutareInvalidaException : public ExceptieArena
{
    using ExceptieArena::ExceptieArena;
};

class AtacInexistentException : public ExceptieArena
{
    using ExceptieArena::ExceptieArena;
};
