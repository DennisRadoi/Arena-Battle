#include <iostream>
#include <memory>
#include <cstdlib>
#include <ctime>
#include <vector>
#include <string>
#include "Arena.h"
#include "Jucator.h"
#include "AI.h"
#include "Luptator.h"

std::shared_ptr<Luptator> alegeStilLuptator(const std::string& nume)
{
    std::cout << "Alege tipul tau de luptator:\n";
    std::cout << "1. Mage\n2. Warrior\n3. Healer\n>> ";

    int alegere;
    std::cin >> alegere;
    std::cin.ignore();

    switch (alegere)
    {
        case 1: return std::make_shared<Mage>(nume, 0, 0);
        case 2: return std::make_shared<Warrior>(nume, 0, 0);
        case 3: return std::make_shared<Healer>(nume, 0, 0);
        default:
            std::cout << "Alegere invalida. Vei fi Mage implicit.\n";
            return std::make_shared<Mage>(nume, 0, 0);
    }
}

std::shared_ptr<Luptator> genereazaStilAI()
{
    static const std::vector<std::string> stiluri = {"mage", "warrior", "healer"};
    int idx = rand() % stiluri.size();
    const std::string& tip = stiluri[idx];

    if (tip == "mage")
        return std::make_shared<Mage>("AI_Mage", 0, 0);
    if (tip == "warrior")
        return std::make_shared<Warrior>("AI_Warrior", 0, 0);
    return std::make_shared<Healer>("AI_Healer", 0, 0);
}

int main()
{
    srand(static_cast<unsigned>(time(nullptr)));

    Arena arena;
    arena.initObstacole();

    std::cout << "Introdu numele jucatorului: ";
    std::string nume;
    std::getline(std::cin, nume);
    if (nume.empty())
    {
        std::cout << "Nume gol, folosim 'Player'.\n";
        nume = "Player";
    }

    auto stilJucator = alegeStilLuptator(nume);
    auto jucator = std::make_shared<Jucator>(nume, 0, 0, stilJucator);
    arena.adaugaLuptator(jucator);

    auto stilAI = genereazaStilAI();
    arena.adaugaLuptator(stilAI);
    AI adversar(stilAI);

    bool esteRandulJucatorului = (rand() % 2 == 0);
    std::cout << "\n>> " << (esteRandulJucatorului ? "Jucatorul muta primul!" : "AI-ul muta primul!") << "\n\n";

    while (!arena.jocTerminat())
    {
        arena.afiseazaArena();

        std::cout << "Status luptatori:\n";
        for (const auto& f : arena.getListaLuptatori())
        {
            if (f->esteViu())
                std::cout << f->getNume() << " (HP: " << f->getHP() << ")\n";
        }
        std::cout << "----------------------\n";

        if (esteRandulJucatorului)
        {
            try{
                jucator->decideActiune(arena, jucator);
            } catch (const std::exception& e) {
                std::cout << "Eroare: " << e.what() << "\n";
            }
        } else
            adversar.executaRunda(arena);

        esteRandulJucatorului = !esteRandulJucatorului;
    }

    arena.afiseazaArena();
    for (const auto& f : arena.getListaLuptatori())
    {
        if (f->esteViu())
        {
            std::cout << "Castigator: " << f->getNume() << "!\n";
            break;
        }
    }

    return 0;
}
