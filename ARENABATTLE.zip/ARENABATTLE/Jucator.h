#pragma once

#include "Luptator.h"
#include "Arena.h"
#include <memory>
#include <string>

class Jucator : public Luptator
{
private:
    std::shared_ptr<Luptator> stil;
    std::string simbol;

public:
    Jucator(std::string& nume, int x, int y, std::shared_ptr<Luptator> stilLupta);

    void ataca(Luptator& tinta) override;
    std::string getSimbol() const override;
    void decideActiune(Arena& arena, std::shared_ptr<Jucator> self);
    int getSansaRatare() const override;
};
