#pragma once

#include <string>
#include <memory>

class Luptator
{
protected:
    std::string nume;
    int x;
    int y;
    int hp;
    int hpMAX;
    bool aparare = false;
    static int sansaCritic;

public:
    Luptator(const std::string& n, int startX, int startY, int viata);
    Luptator(const Luptator& other);
    Luptator& operator=(const Luptator& other);
    virtual ~Luptator() = default;

    virtual void ataca(Luptator& target) = 0;
    virtual std::string getSimbol() const = 0;

    virtual int getSansaRatare() const = 0;

    bool rateazaAtacul() const;
    bool areCritic() const;

    bool esteViu() const;
    bool esteAI() const;
    void setPoz(int nouX, int nouY);
    int getX() const;
    int getY() const;
    std::string getNume() const;
    int getHP() const;
    int getViata() const;

    void incaseazaDamage(int dmg);
    void vindeca(int v);

    void startAparare();
    void stopAparare();
    bool seApara() const;

    static void seteazaSansaCritic(int sansa);
    static int getSansaCritic();
};

// Clasele de luptatori

class Mage : public Luptator
{
public:
    Mage(const std::string& n, int x, int y);
    Mage(const Mage& other);
    Mage& operator=(const Mage& other);

    void ataca(Luptator& target) override;
    std::string getSimbol() const override;
    int getSansaRatare() const override;
};

class Warrior : public Luptator
{
public:
    Warrior(const std::string& n, int x, int y);
    Warrior(const Warrior& other);
    Warrior& operator=(const Warrior& other);

    void ataca(Luptator& target) override;
    std::string getSimbol() const override;
    int getSansaRatare() const override;
};

class Healer : public Luptator
{
private:
    int numarVindecari = 2;

public:
    Healer(const std::string& n, int x, int y);
    Healer(const Healer& other);
    Healer& operator=(const Healer& other);

    void ataca(Luptator& tinta) override;
    std::string getSimbol() const override;

    void vindecare();
    bool maiPoateVindeca() const;
    void consumaVindecare();
    int getNumarVindecari() const;
    int getSansaRatare() const override;
};
